require 'rails_helper'
require 'city_validator'

RSpec.describe CityValidator do
  describe '.valid?' do
    context 'when the city is valid' do
      it 'returns true' do
        city_name = 'Mumbai'
        api_key = 'c4c64763a8597bb1bee809bc3178e98e' # Replace with a valid API key

        # Stub the HTTP request to always return a 200 OK response
        allow(HTTParty).to receive(:get).and_return(double(code: 200))

        result = CityValidator.valid?(city_name)

        expect(result).to be(true)
      end
    end

    context 'when the city is invalid' do
      it 'returns false' do
        city_name = 'Invalid address'
        api_key = 'c4c64763a8597bb1bee809bc3178e98e' # Replace with a valid API key

        # Stub the HTTP request to return a non-200 response (e.g., 404)
        allow(HTTParty).to receive(:get).and_return(double(code: 404))

        result = CityValidator.valid?(city_name)

        expect(result).to be(false)
      end
    end
  end
end
