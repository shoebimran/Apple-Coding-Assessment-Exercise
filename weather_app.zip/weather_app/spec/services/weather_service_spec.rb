# spec/services/weather_service_spec.rb

require 'rails_helper'
require 'weather_service'

RSpec.describe WeatherService do
  describe '#fetch_weather_data_and_check_cache' do
    context 'when data is not found in cache' do
      it 'fetches data from the API and caches it' do
        city_name = 'Mumbai'
        api_key = 'c4c64763a8597bb1bee809bc3178e98e' # Replace with your actual API key

        # Make a real HTTP request to the external API
        response = HTTParty.get("https://api.openweathermap.org/data/2.5/weather?q=#{city_name}&appid=#{api_key}&units=metric")

        # Check if the response status code is 200 (OK)
        expect(response.code).to eq(200)

        # Parse the response body as JSON
        weather_data = JSON.parse(response.body)

        service = WeatherService.new(city_name)
        cached_weather_data, cached_data_flag = service.fetch_weather_data_and_check_cache

        expect(weather_data['main']['temp']).to eq(cached_weather_data['main']['temp'])
        expect(cached_data_flag).to be(true)
      end
    end
  end
end
