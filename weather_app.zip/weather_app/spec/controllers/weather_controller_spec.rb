require 'rails_helper'

RSpec.describe WeatherController, type: :controller do
  describe 'GET #forecast' do
    context 'when a valid city is provided' do
      it 'returns a successful response' do
        get :forecast, params: { address: 'Mumbai' }
        expect(response).to have_http_status(:success)
      end

      it 'assigns the correct instance variables' do
        get :forecast, params: { address: 'Mumbai' }
        expect(assigns(:valid_city)).to eq('Mumbai')
        expect(assigns(:cached_data_flag)).to be_in([true, false])
        # Add more expectations for other instance variables
      end
    end

    it 'redirects to the root path with an error flash message' do
      get :forecast, params: { address: 'Invalid address' }
      expect(response).to redirect_to(root_path)
      expect(flash[:error]).to be_present
    end
  end
end
