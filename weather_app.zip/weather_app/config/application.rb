require_relative "boot"
require "rails/all"

Bundler.require(*Rails.groups)

module WeatherApp
  class Application < Rails::Application
    config.load_defaults 7.0
    config.autoload_paths << Rails.root.join("lib")

    env_file = Rails.root.join("config", "local_env.yml")
    YAML.load_file(env_file).each { |key, value| ENV[key.to_s] = value } if File.exist?(env_file)
    config.cache_store = :redis_cache_store, {
  url: 'redis://localhost:6379/0/cache'
}

    config.cache_store = Rails.env.production? ? :redis_cache_store : [:memory_store, { size: 1024.megabytes }]
  end
end
