Rails.application.routes.draw do
  root "weather#index"
  get 'forecast' => 'weather#forecast'
end
