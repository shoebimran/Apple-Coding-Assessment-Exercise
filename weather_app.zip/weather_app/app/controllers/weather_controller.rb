class WeatherController < ApplicationController
  before_action :fetch_valid_city, only: [:forecast]

  def index
  end

  def forecast
  if @valid_city
    weather_service = WeatherService.new(@valid_city)
    weather_data, cached_data_flag = weather_service.fetch_weather_data_and_check_cache

    @cached_data_flag = cached_data_flag

    @temperature = weather_data.dig("main", "temp")
    @high_temperature = weather_data.dig("main", "temp_max")
    @low_temperature = weather_data.dig("main", "temp_min")

    cache_input_and_weather_data(@valid_city, weather_data, cached_data_flag)
  else
    flash[:error] = "City not found"
    redirect_to root_path
  end
end
  
  private

  def fetch_valid_city
    address = params[:address]
    @valid_city = address.split(' ').find { |word| CityValidator.valid?(word) }
  end

  def cache_input_and_weather_data(city_name, weather_data, cached_data_flag)
    cache_expiry = 30.minutes

    Rails.cache.write("input_value_#{city_name}", params[:address], expires_in: cache_expiry)
    Rails.cache.write("weather_data_#{city_name}", weather_data, expires_in: cache_expiry)
    Rails.cache.write("cached_data_flag_#{city_name}", cached_data_flag, expires_in: cache_expiry)
  end
end
