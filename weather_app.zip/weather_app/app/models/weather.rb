class Weather < ApplicationRecord
end
