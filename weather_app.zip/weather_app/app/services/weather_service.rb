class WeatherService
  def initialize(city_name)
    @city_name = city_name
  end

  def fetch_weather_data_and_check_cache
    cache_key = "weather_data_#{@city_name}"
    weather_data = Rails.cache.fetch(cache_key, expires_in: 30.minutes) do
      fetched_data = fetch_weather_data
     fetched_data['cached_at'] = Time.now # Add a 'cached_at' timestamp to the data
     fetched_data
   end

   cached_data_flag = false

   if weather_data && weather_data['cached_at']
    cached_data_flag = true
  else
    weather_data = fetch_weather_data
  end

  [weather_data, cached_data_flag]
end

private

def fetch_weather_data
  api_key = ENV['OPENWEATHERMAP_API_KEY']
  response = HTTParty.get("https://api.openweathermap.org/data/2.5/weather?q=#{@city_name}&appid=#{api_key}&units=metric")

  handle_api_error(response) if response.code != 200

  JSON.parse(response.body)
end

def handle_api_error(response)
  flash[:error] = "Weather data request failed: #{response.message}"
  redirect_to root_path
end
end
