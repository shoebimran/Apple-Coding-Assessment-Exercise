class CityValidator
  def self.valid?(city_name)
    api_key = ENV['OPENWEATHERMAP_API_KEY']
    response = HTTParty.get("https://api.openweathermap.org/data/2.5/weather?q=#{city_name}&appid=#{api_key}")
    response.code == 200
  end
end