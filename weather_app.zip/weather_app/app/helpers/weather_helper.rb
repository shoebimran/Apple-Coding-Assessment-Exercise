module WeatherHelper
end
